<template>
  <view>hello world</view>
</template>

<script>
import wepy from 'wepy'

export default class PersonIndex extends wepy.page {
  config = {
    navigationBarTitleText: '测试商城个人主页'
  }
}
</script>
