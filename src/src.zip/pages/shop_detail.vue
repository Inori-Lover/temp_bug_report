<template>
  <view>hello world</view>
</template>

<script>
import wepy from 'wepy'

export default class ItemDetail extends wepy.page {
  config = {
    navigationBarTitleText: '测试商城商品详情'
  }
}
</script>
