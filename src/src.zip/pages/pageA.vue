<template>
    <view>
      <button @tap="test1"> test1 {{from}}</button>
      <button @tap="test2"> test2 {{from}}</button>
    </view>
</template>

<script>
import wepy from 'wepy'

export default class Web extends wepy.page {
  data = {
    src: '',
    from: null
  }
  methods = {
    test1 () {
      this.$navigate('./pageA', {from: 1})
    },
    test2 () {
      this.$navigate('./pageB', {from: 2})
    }
  }
  onLoad(options) {
    // console.log(options.from, getCurrentPages()[getCurrentPages().length - 1].__wxWebviewId__)
    this.loading = true
    this.from = options.from || 'null'
    // console.log(options, that.__wxWebviewId__)
    // setTimeout(function () {
    //   // console.log(options, that.__wxWebviewId__)
    //   that.setData({ loading: false, name: options.from }, function() {})
    // }, 2000)
  }
}
</script>
